# Strong Towns browser graphics

`@strongtowns/graphics-browser` renders explicit bar-chart and count-card inputs
into SVG pages and browser PNG downloads. It has no runtime dependencies and
does not select records or infer labels, colors, methodology, or editorial copy.
The Python API is unchanged.

```js
import { renderGraphic, pngBlob } from '@strongtowns/graphics-browser';
const pages = renderGraphic({
  kind: 'bars', format: 'instagram', title: 'Recorded cases',
  explanation: 'Each case is counted once.', notes: 'Source: reviewed minutes.',
  brand: 'STRONG TOWNS', countLabel: 'recorded cases', total: 3,
  rows: [{ label: 'Granted', value: 2 }, { label: 'Unknown', value: 1 }],
});
// In a browser: await pngBlob(pages[0]);
```

`renderGraphic(input, {fontCss, measure})` is pure and returns SVG, alt text,
width, and height for each page. `measure(text, size)` should use the loaded
export font (bold at size 54, regular otherwise). The conservative default
supports server-side checks. Text overflow fails explicitly. Bars paginate with
one global scale. Values must sum to the supplied total. All text is escaped.

`embeddedFontCss(urls, family)` loads same-origin WOFF2 files for self-contained
SVGs. Supply trusted font CSS only; editorial strings belong in the input text
fields. `pngBlob(page)` uses the same SVG and releases its temporary object URL.
The caller owns download controls and error presentation.

Publishing formats preserve the existing Python targets: `instagram` is
1080 × 1350; `instagram_story` is 1080 × 1920 with the feed composition offset
by 14% of the story height. Text is never smaller than 24 canvas pixels.

Run `npm test`. Inspect PNGs in supported browsers after layout changes.
Consumers may install a versioned `npm pack` archive without a package registry.
Change the package version when distributing a changed renderer.

## Prepared vector maps (0.2.0)

`renderMap(scene, selectedIds, prefix)` returns the fixed geographic SVG. The
scene owns geometry, symbol IDs, original projected coordinates, displaced
positions, radii, colors, and opacity. Selection hides symbols without recalculating
placement. Use a distinct prefix for each inline map to isolate SVG definition IDs.
Scenes must be trusted, verified build artifacts, not user-uploaded SVG.

`renderMapGraphic({scene, ids, title, explanation, notes, brand, attribution},
{fontCss, measure})` composes that same map into the fixed 1080 × 1350 publishing
frame with category and hearing-size legends. `pngBlob` exports the returned page.
The publishing extent has no camera input. Text overflow is an explicit error.

Python's `categorical_proportional_symbol_map(..., include_scene=True)` adds a
JSON-serializable `map_scene` to metadata. It uses the print renderer's actual
coordinate transform, basemap paths, and deterministic symbol placement. Existing
calls and print outputs remain unchanged unless the opt-in flag is supplied.
