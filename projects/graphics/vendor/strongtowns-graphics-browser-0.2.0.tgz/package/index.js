/** Browser-safe rendering: inputs are explicit; no data selection or editorial inference. */
export const FORMATS = Object.freeze({ instagram: { width: 1080, height: 1350, offset: 0 }, instagram_story: { width: 1080, height: 1920, offset: 1920 * .14 } });
const escape = (s) => String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' })[c]);

function lines(text, size, width, measure) {
  const result = [];
  for (const paragraph of text.split('\n')) {
    let line = '';
    for (const word of paragraph.split(/\s+/).filter(Boolean)) {
      if (measure(word, size) > width) throw new Error('A word is too long to fit. Shorten the text.');
      const next = line ? `${line} ${word}` : word;
      if (measure(next, size) > width) { result.push(line); line = word; } else line = next;
    }
    result.push(line);
  }
  return result;
}

export function renderGraphic(input, options = {}) {
  const format = FORMATS[input.format];
  if (!format || !['bars', 'count'].includes(input.kind)) throw new Error('Unsupported graphic format or kind.');
  if (!Number.isSafeInteger(input.total) || input.total <= 0) throw new Error('Choose at least one case before exporting.');
  if (!input.title.trim()) throw new Error('Enter a headline.');
  if (input.rows.some((r) => !r.label || !Number.isSafeInteger(r.value) || r.value < 0)) throw new Error('Invalid chart values.');
  if (input.kind === 'bars' && input.rows.reduce((sum, r) => sum + r.value, 0) !== input.total) throw new Error('Chart values must add up to the stated total.');
  const theme = { background: '#f5f1e8', foreground: '#202b29', accent: '#276451', ...input.theme };
  if (Object.values(theme).some((color) => !/^#[a-f\d]{6}$/i.test(color))) throw new Error('Theme colors must be six-digit hex colors.');
  const measure = options.measure ?? ((s, size) => Array.from(s).length * size * .62);
  const title = lines(input.title, 54, 960, measure);
  const explanation = lines(input.explanation, 28, 960, measure);
  const notes = lines(input.notes, 26, 960, measure);
  if (title.length > 3 || explanation.length > 3 || notes.length > 7) throw new Error('Text does not fit. Shorten the headline or explanation, or reduce the filter selection.');
  const rows = input.rows.map((row) => ({ ...row, lines: lines(row.label, 30, 810, measure) }));
  if (rows.some((row) => row.lines.length > 2)) throw new Error('A category label is too long to fit.');
  const top = 115 + title.length * 64 + 26 + explanation.length * 36 + 38;
  const bottom = 1260 - notes.length * 33 - 28;
  const pages = [[]];
  let used = 0;
  if (input.kind === 'bars') for (const row of rows) {
    const height = row.lines.length * 38 + 39;
    if (top + used + height > bottom) { pages.push([]); used = 0; }
    if (top + height > bottom) throw new Error('The notes leave no room for the chart.');
    pages.at(-1).push(row); used += height;
  }
  const maximum = Math.max(1, ...rows.map((row) => row.value));
  return pages.map((page, index) => {
    const text = (value, x, y, size, extra = '') => `<text x="${x}" y="${y}" font-size="${size}" ${extra}>${escape(value)}</text>`;
    const block = (values, y, size, lineHeight, extra = '') => values.map((v, i) => text(v, 60, y + i * lineHeight, size, extra)).join('');
    let chart = '', y = top;
    if (input.kind === 'count') {
      if (bottom - top < 230) throw new Error('Shorten the text to leave room for the count.');
      const value = input.total.toLocaleString('en-US');
      if (measure(value, 180) > 960 || measure(input.countLabel, 32) > 960) throw new Error('The count or its label is too wide to fit.');
      const baseline = top + (bottom - top) / 2 + 54;
      chart = text(value, 60, baseline, 180, 'font-weight="700"') + text(input.countLabel, 60, baseline + 55, 32);
    } else for (const row of page) {
      chart += block(row.lines, y, 30, 38);
      chart += text(row.value.toLocaleString('en-US'), 1020, y, 30, 'text-anchor="end" font-weight="700"');
      y += row.lines.length * 38;
      chart += `<rect x="60" y="${y - 17}" width="${960 * row.value / maximum}" height="17" fill="${theme.accent}"/>`;
      y += 39;
    }
    const altText = `${input.title}. ${input.explanation} ${input.kind === 'count' ? `${input.total} ${input.countLabel}.` : page.map((row) => `${row.label}: ${row.value}`).join('; ') + '.'} ${input.notes} Image ${index + 1} of ${pages.length}.`;
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${format.width}" height="${format.height}" viewBox="0 0 ${format.width} ${format.height}" role="img"><title>${escape(input.title)}</title><desc>${escape(altText)}</desc><defs><style>${options.fontCss ?? ''}</style></defs><rect width="100%" height="100%" fill="${theme.background}"/><g transform="translate(0 ${format.offset})" fill="${theme.foreground}" font-family="Inter, sans-serif">${text(input.brand, 60, 63, 26, 'font-weight="700"')}${block(title, 130, 54, 64, 'font-weight="700"')}${block(explanation, 130 + title.length * 64 + 20, 28, 36)}${chart}${block(notes, 1260 - notes.length * 33, 26, 33)}${text(`Image ${index + 1} of ${pages.length}`, 60, 1300, 24)}</g></svg>`;
    return { svg, altText, width: format.width, height: format.height };
  });
}

/** Fetch and embed caller-supplied, same-origin WOFF2 fonts for offline SVGs. */
export async function embeddedFontCss(urls, family = 'Inter') {
  if (!/^[\w -]+$/.test(family)) throw new Error('Invalid font family.');
  return (await Promise.all(urls.map(async (url) => {
    if (new URL(url, location.href).origin !== location.origin) throw new Error('Use same-origin fonts.');
    const response = await fetch(url);
    if (!response.ok) throw new Error('Fonts could not load. Retry the preview.');
    const bytes = new Uint8Array(await response.arrayBuffer());
    if (String.fromCharCode(...bytes.slice(0, 4)) !== 'wOF2') throw new Error('The font file is invalid.');
    let binary = ''; for (const byte of bytes) binary += String.fromCharCode(byte);
    return `@font-face{font-family:'${family}';src:url(data:font/woff2;base64,${btoa(binary)}) format('woff2');font-weight:100 900;font-style:normal;}`;
  }))).join('\n');
}

export async function pngBlob(page) {
  const url = URL.createObjectURL(new Blob([page.svg], { type: 'image/svg+xml' }));
  try {
    const img = new Image();
    await new Promise((resolve, reject) => {
      const timeout = setTimeout(() => reject(new Error('Image rendering timed out. Retry the download.')), 15000);
      img.onload = () => { clearTimeout(timeout); resolve(); };
      img.onerror = () => { clearTimeout(timeout); reject(new Error('Image rendering failed. Retry or download SVG.')); };
      img.src = url;
    });
    const canvas = document.createElement('canvas'); canvas.width = page.width; canvas.height = page.height;
    const context = canvas.getContext('2d'); if (!context) throw new Error('This browser cannot export PNG. Download SVG instead.');
    context.drawImage(img, 0, 0);
    return await new Promise((resolve, reject) => canvas.toBlob((blob) => blob ? resolve(blob) : reject(new Error('PNG export failed. Download SVG instead.')), 'image/png'));
  } finally { URL.revokeObjectURL(url); }
}

export { renderMap, renderMapGraphic, validateMapScene } from './map.js';
