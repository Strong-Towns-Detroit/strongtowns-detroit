/** A prepared scene owns geometry and placement; interaction only selects symbols. */
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'})[c]);
export function validateMapScene(scene) {
  if (scene?.version !== 1 || !Number.isFinite(scene.width) || scene.width <= 0 || !Number.isFinite(scene.height) || scene.height <= 0 || typeof scene.basemap !== 'string' || !Array.isArray(scene.symbols)) throw new Error('Unsupported map scene.');
  // Scenes are trusted build artifacts, never uploaded user SVG.
  if (/<\s*(script|foreignObject|image)|\son\w+\s*=|(?:href\s*=\s*["'](?:https?:|javascript:))/i.test(scene.basemap)) throw new Error('Unsafe map scene.');
  if (![scene.background,scene.stroke].every(c=>/^#[a-f\d]{6}$/i.test(c)) || !Number.isFinite(scene.opacity) || scene.opacity<0 || scene.opacity>1 || !Number.isFinite(scene.strokeWidth) || scene.strokeWidth<0) throw new Error('Invalid map styling.');
  const ids = new Set();
  for (const s of scene.symbols) {
    if (!s.id || ids.has(s.id) || ![s.x,s.y,s.radius,s.magnitude].every(Number.isFinite) || s.radius <= 0 || !/^#[a-f\d]{6}$/i.test(s.color)) throw new Error('Invalid map symbol.');
    ids.add(s.id);
  }
  return scene;
}
export function renderMap(scene, ids = scene.symbols.map(s => s.id), prefix = 'map') {
  validateMapScene(scene);
  if (!/^[a-z][\w-]*$/i.test(prefix)) throw new Error('Invalid map prefix.');
  const selected = new Set(ids);
  const base = scene.basemap.replace(/\bid="([^"]+)"/g, (_, id) => `id="${prefix}-${id}"`).replace(/url\(#([^)]+)\)/g, (_, id) => `url(#${prefix}-${id})`).replace(/(href=")#([^"]+)"/g, (_, attr, id) => `${attr}#${prefix}-${id}"`);
  const symbols = scene.symbols.filter(s => selected.has(s.id)).map(s => `<circle data-case-id="${esc(s.id)}" cx="${s.x}" cy="${s.y}" r="${s.radius}" fill="${s.color}" stroke="${esc(scene.stroke)}" stroke-width="${scene.strokeWidth}" opacity="${scene.opacity}"><title>${esc(s.label)} · ${s.magnitude} hearings</title></circle>`).join('');
  return `<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 ${scene.width} ${scene.height}" width="${scene.width}" height="${scene.height}"><g data-map-layer="basemap">${base}</g><g data-map-layer="cases">${symbols}</g></svg>`;
}
function wrap(value, size, width, measure) {
  const lines = []; let line = '';
  for (const word of value.replaceAll('/', '/ ').trim().split(/\s+/)) {
    if (measure(word,size) > width) throw new Error('A word is too long. Shorten the text.');
    const next = line ? `${line} ${word}` : word;
    if (measure(next,size) > width) { lines.push(line); line = word; } else line = next;
  }
  if(line) lines.push(line); return lines;
}
export function renderMapGraphic(input, options = {}) {
  const scene = validateMapScene(input.scene), ids = new Set(input.ids);
  const symbols = scene.symbols.filter(s => ids.has(s.id));
  if (!symbols.length) throw new Error('Select at least one mapped case.');
  if (!input.title.trim()) throw new Error('Enter a headline.');
  const measure = options.measure ?? ((s,size) => [...s].length * size * .55);
  const title = wrap(input.title,48,960,measure), explanation = wrap(input.explanation,26,960,measure);
  if (title.length > 2 || explanation.length > 2 || title.length + explanation.length > 3) throw new Error('Shorten the headline or explanation to fit the graphic.');
  const text = (v,x,y,size,extra='') => `<text x="${x}" y="${y}" font-size="${size}" ${extra}>${esc(v)}</text>`;
  let markup = text(input.brand,60,30,26,'font-weight="700"') + text(input.attribution,60,60,24);
  title.forEach((v,i)=>markup+=text(v,60,113+i*50,48,'font-weight="700"'));
  explanation.forEach((v,i)=>markup+=text(v,60,166+(title.length-1)*30+i*30,26));
  // Fixed map scale: 1570 / 1600 of the publishing canvas, as in MobileMapLayout.
  const width = 1015 * 1570 / 1047 * 1080 / 1600, height = width * scene.height / scene.width;
  markup += `<g transform="translate(${(1080-width)/2} 206) scale(${width/scene.width})">${renderMap(scene,[...ids],'publication')}</g>`;
  const groups = new Map();
  for(const s of symbols) { const g=groups.get(s.category)??{label:s.label,color:s.color,count:0};g.count++;groups.set(s.category,g); }
  const rows=[...groups.values()].sort((a,b)=>b.count-a.count||a.label.localeCompare(b.label,'en'));
  const legendY = 206 + height + 14;
  rows.forEach((g,i)=>{
    const x=35+(i%3)*345, y=legendY+Math.floor(i/3)*48;
    const label=wrap(`${g.label} (${g.count})`,24,306,measure);
    if(label.length>2) throw new Error('A legend label does not fit.');
    markup+=`<circle cx="${x}" cy="${y-7}" r="6" fill="${g.color}"/>`;
    label.forEach((v,j)=>markup+=text(v,x+13,y+j*24,24));
  });
  let y=legendY+Math.ceil(rows.length/3)*48+4;
  markup+=text('HEARINGS PER CASE',760,206+height-140,24,'font-weight="700"');
  const ceiling=Math.max(1,Math.ceil(Math.max(...scene.symbols.map(s=>s.magnitude))/2)*2);
  const levels=[...new Set([ceiling,ceiling/2,1])], unit=symbols[0].radius/Math.sqrt(symbols[0].magnitude)*width/scene.width;
  levels.forEach((n,i)=>{const r=unit*Math.sqrt(n), cy=206+height-103+i*36;markup+=`<circle cx="785" cy="${cy}" r="${r}" fill="#8c939a" stroke="#fffaf0"/>`+text(n,820,cy+8,24);});
  const notes=wrap(input.notes,24,1010,measure);
  if(y+notes.length*28>1340) throw new Error('Source notes do not fit. Shorten the selection description.');
  notes.forEach((v,i)=>markup+=text(v,35,y+i*28,24));
  const altText=`${input.title}. ${input.explanation} ${symbols.length} mapped cases. ${input.notes}`;
  return {width:1080,height:1350,altText,svg:`<svg xmlns="http://www.w3.org/2000/svg" width="1080" height="1350" viewBox="0 0 1080 1350" role="img"><title>${esc(input.title)}</title><desc>${esc(altText)}</desc><defs><style>${options.fontCss??''}</style></defs><rect width="1080" height="1350" fill="${scene.background}"/><g fill="#0c2340" font-family="Inter, sans-serif">${markup}</g></svg>`};
}
