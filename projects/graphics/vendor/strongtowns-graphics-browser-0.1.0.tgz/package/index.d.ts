export type PublishingFormat = 'instagram' | 'instagram_story';
export type GraphicRow = { label: string; value: number };
export type GraphicInput = { kind: 'bars' | 'count'; format: PublishingFormat; title: string; explanation: string; notes: string; brand: string; countLabel: string; total: number; rows: GraphicRow[]; theme?: { background?: string; foreground?: string; accent?: string } };
export type GraphicPage = { svg: string; altText: string; width: number; height: number };
export const FORMATS: Readonly<Record<PublishingFormat, { width: number; height: number; offset: number }>>;
export function renderGraphic(input: GraphicInput, options?: { fontCss?: string; measure?: (text: string, size: number) => number }): GraphicPage[];
export function embeddedFontCss(urls: string[], family?: string): Promise<string>;
export function pngBlob(page: GraphicPage): Promise<Blob>;
